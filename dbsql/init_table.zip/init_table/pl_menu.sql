INSERT INTO `pl_menu` VALUES ('pl', '平台管理', NULL, '平台管理', '1', NULL, NULL, '99000000');
INSERT INTO `pl_menu` VALUES ('pl0002', '角色管理', 'pl/pl0002', '增加、修改、删除用户角色', '0', 'pl', NULL, '99000002');
INSERT INTO `pl_menu` VALUES ('pl0003', '用户管理', 'pl/pl0003', '增加、冻结用户', '0', 'pl', NULL, '99000001');
INSERT INTO `pl_menu` VALUES ('pl0004', '角色权限管理', 'pl/pl0004', '为角色授权或删除授权', '0', 'pl', NULL, '99000004');
INSERT INTO `pl_menu` VALUES ('pl0005', '用户特有权限管理', 'pl/pl0005', '为用户分配或收回特有权限', '0', 'pl', NULL, '99000005');
