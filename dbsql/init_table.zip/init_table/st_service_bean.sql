INSERT INTO `st_service_bean` VALUES ('P11000', 'loginPl', 'P', '后台登陆', 'N', 'manage');
INSERT INTO `st_service_bean` VALUES ('S10001', 'cutPageServiceImpl', 'P', '分页', 'N', 'frame');
INSERT INTO `st_service_bean` VALUES ('S10002', 'autoSearchService', 'P', '自动页面查询', 'N', 'frame');
INSERT INTO `st_service_bean` VALUES ('S24004', 'getExamTest', 'P', '获取menu', 'Y', 'manage');
INSERT INTO `st_service_bean` VALUES ('S24023', 'loginSj', 'P', '获取留言', 'Y', 'manage');
